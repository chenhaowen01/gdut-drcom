#!/bin/sh
sh prerm-pkg
rm -f /etc/gdut-drcom.conf /etc/init.d/gdut-drcom /usr/bin/gdut-drcom
