#!/bin/sh
tar xvf data.tar -C /
sh postinst-pkg

